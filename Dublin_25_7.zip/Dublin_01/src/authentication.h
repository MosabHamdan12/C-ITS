#ifndef ATHO_AUTHENTICATION_AUTHENTICATION_H_
#define ATHO_AUTHENTICATION_AUTHENTICATION_H_
#include <omnetpp.h>
#include "SHA256.h"
#include "msg_m.h"
using namespace omnetpp;
class authentication {
public:
    authentication(){};
    virtual ~authentication(){};

    const char* hash(int N){
        std::ostringstream str;
        str << N ;
        return sha256(str.str()).c_str();
    }
    const char* hash(std::string S){
        return sha256(S).c_str();
    }
    const char* hash(std::vector<std::string> s){
         std::ostringstream str;
            for (auto i = s.begin(); i != s.end(); ++i)
                str << *i ;
        return sha256(str.str()).c_str();
    }

    std::string _xor(std::string S1,std::string S2){
        return str_xor(S1, S2);
    }
    static inline unsigned int value(char c){
        if (c >= '0' && c <= '9') { return c - '0';      }
        if (c >= 'a' && c <= 'f') { return c - 'a' + 10; }
        if (c >= 'A' && c <= 'F') { return c - 'A' + 10; }
        return -1;
    }

    std::string str_xor(std::string const & s1, std::string const & s2){
        assert(s1.length() == s2.length());
        static char const alphabet[] = "0123456789abcdef";
        std::string result;
        result.reserve(s1.length());
        for (std::size_t i = 0; i != s1.length(); ++i){
            unsigned int v = value(s1[i]) ^ value(s2[i]);
            assert(v < sizeof alphabet);
            result.push_back(alphabet[v]);
        }

        return result;
    }


    cMessage *create_CONNECT(std::string ID) {
        CONNECT *My_msg = new CONNECT("CONNECT");
        My_msg->setDevice_ID(ID.c_str());
        return My_msg;
    }
    cMessage *create_Registration(std::string AID,int port) {
        Registration *My_msg = new Registration("Registration");
        My_msg->setDevice_ID(AID.c_str());
        My_msg->setPort(port);
        return My_msg;
    }
    cMessage *create_parameters(std::string AIDA,std::string SKAS_A,std::string Hash1) {
        parameters *My_msg = new parameters("parameters");
            My_msg->setDevice_AID(AIDA.c_str());
            My_msg->setDevice_SK(SKAS_A.c_str());
            My_msg->setHash1(Hash1.c_str());
        return My_msg;
    }
    cMessage *create_Request(std::string C1,std::string C2,std::string C3,std::string Hash2) {
        Request *My_msg = new Request("Request");
        My_msg->setC1(C1.c_str());       // (5)
        My_msg->setC2(C2.c_str());       // (6)
        My_msg->setC3(C3.c_str());       // (7)
        My_msg->setHash2(Hash2.c_str()); // (8)
        return My_msg;
    }
    cMessage *create_Manager_Verification(std::string Verifier,std::string Hash3) {
        Manager_Verification *My_msg = new Manager_Verification("Manager_Verification");
        My_msg->setVerifier(Verifier.c_str());
        My_msg->setHash3(Hash3.c_str());
        return My_msg;
    }
    cMessage *create_Device_Verification(std::string Hash5) {
        Device_Verification *My_msg = new Device_Verification("Device_Verification");
        My_msg->setHash5(Hash5.c_str());       // (5)
        return My_msg;
    }
    cMessage *create_Request_Forward(std::string Broker_SK,std::string C4,std::string C6,std::string C8,std::string Hash4,int port) {
        Request_Forward *My_msg = new Request_Forward("Request_Forward");
        My_msg->setBroker_SK(Broker_SK.c_str());
        My_msg->setC4(C4.c_str());
        My_msg->setC6(C6.c_str());
        My_msg->setC8(C8.c_str());
        My_msg->setHash4(Hash4.c_str());
        My_msg->setPort(port);
        return My_msg;
    }
    cMessage *create_Broker_Verification(std::string C10,std::string Hash6) {
        Broker_Verification *My_msg = new Broker_Verification("Broker_Verification");
        My_msg->setC10(C10.c_str());
        My_msg->setHash6(Hash6.c_str());
        return My_msg;
    }
    cMessage *create_SessionKey_Verification(std::string C11,std::string Hash7) {
        SessionKey_Verification *My_msg = new SessionKey_Verification("SessionKey_Verification");

        My_msg->setC11(C11.c_str());
        My_msg->setHash7(Hash7.c_str());
        return My_msg;
    }
};

#endif

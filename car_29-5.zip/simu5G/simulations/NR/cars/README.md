***************************************
*     Simu5G - NR Cars example        *
***************************************

This simulation example uses the Veins library (veins.car2x.org) to endow 
the UEs with vehicular mobility simulated by the SUMO traffic simulator 
(eclipse.org/sumo). 

In order to run an example from the "cars" folder, you need to launch SUMO 
before running the simulation. 
To do so, click on the SUMO launcher in the dock on the left side of 
the screen. This will open a new terminal window, which must be kept 
open for the entire duration of the simulation.

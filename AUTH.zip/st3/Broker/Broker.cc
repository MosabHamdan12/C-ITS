#include "Broker.h"

Define_Module(Broker);

void Broker::initialize(){
    srand(time(0));
    selfMsg = new cMessage("sendTimer");
}

void Broker::handleMessage(cMessage *msg){
    if (msg->isSelfMessage()) {
        ASSERT(msg == selfMsg);
        switch (selfMsg->getKind()) {
            case start:
                break;
        }
     }else{
         Base_msg *_msg = check_and_cast<Base_msg *>(msg);
         switch (_msg->getPacket_type()) {
             case _CONNECT:
                 handleCONNECT(msg);
                 break;
             case _Device_Verification:
                 handleDevice_Verification(msg);
                 break;
             case _Request_Forward:
                 handleRequest_Forward(msg);
                 break;
             case _SessionKey_Verification:
                 handleSessionKey_Verification(msg);
                 break;
         }
     }
}

void Broker::handleCONNECT(cMessage *msg){
    CONNECT *CONNECT_msg = check_and_cast<CONNECT *>(msg);
    Session_Broker S;
        S.index       = Session.size();
        S.Session_ID  = auth.hash(rand() % (1000000 - 9999999));
        S.Device_port = msg->getArrivalGate()->getIndex() ;
        S.R3     = auth.hash(rand() % (1000000 - 9999999));
        S._Hash5 = "";
        S.Hash5  = "";
        S.Hash6  = "";
        S.C9     = "";
        S.C10    = "";
        S.Session_key  = "";
    Session.push_back(S);

    send(auth.create_CONNECT(Session[Session.size()-1].Session_ID), "gate$o", Session[Session.size()-1].Device_port);
    send(auth.create_Registration(CONNECT_msg->getDevice_ID(),Session[Session.size()-1].Device_port), "gate$o", 6);
}
void Broker::handleDevice_Verification(cMessage *msg){
    Device_Verification *Device_Verification_msg = check_and_cast<Device_Verification *>(msg);
    int K =-1;
    for (auto i = Session.begin(); i != Session.end(); ++i)
        if (i->Device_port == msg->getArrivalGate()->getIndex())
            K = i->index;
    Session_Broker S;
        S.index       = Session[K].index;
        S.Device_port = Session[K].Device_port;
        S.Session_ID  = Session[K].Session_ID;
        S.R3          = Session[K].R3;
        S._Hash5      = Session[K]._Hash5;
        S.Hash5       = Device_Verification_msg->getHash5();
        S.Hash6       = Session[K].Hash6;
        S.C9          = Session[K].C9;
        S.C10         = Session[K].C10;
        S.Session_key       = Session[K].Session_key;
    Session.at(K) = S;

    if(Session[K].Hash5 == Session[K]._Hash5)
        send(auth.create_Broker_Verification(Session[K].C10,Session[K].Hash6), "gate$o", Session[K].Device_port);
}
void Broker::handleSessionKey_Verification(cMessage *msg){
    SessionKey_Verification *SessionKey_Verification_msg = check_and_cast<SessionKey_Verification *>(msg);
    int K =-1;
    for (auto i = Session.begin(); i != Session.end(); ++i)
       if (i->Device_port == msg->getArrivalGate()->getIndex())
           K = i->index;

    std::string R4    = auth._xor(Session[K].C9,  SessionKey_Verification_msg->getC11());              //(45)
    Session_Broker S;
        S.index       = Session[K].index;
        S.Device_port = Session[K].Device_port;
        S.Session_ID  = Session[K].Session_ID;
        S.R3          = Session[K].R3;
        S._Hash5      = Session[K]._Hash5;
        S.Hash5       = Session[K].Hash5;
        S.Hash6       = Session[K].Hash6;
        S.C9          = Session[K].C9;
        S.C10         = Session[K].C10;
        S.Session_key       = auth.hash({Session[K].R3 , R4})  ;  //(46)
    Session.at(K) = S;

    std::string Hash7 = auth.hash({Session[K].Session_key , SessionKey_Verification_msg->getC11()});//(47)
    if(Hash7 == SessionKey_Verification_msg->getHash7())
        EV << "Session_key : " << Session[K].Session_key << "\n";
}
void Broker::handleRequest_Forward(cMessage *msg){
    Request_Forward *Request_Forward_msg = check_and_cast<Request_Forward *>(msg);
    int K =-1;
    for (auto i = Session.begin(); i != Session.end(); ++i)
        if (i->Device_port == Request_Forward_msg->getPort())
            K = i->index;

    std::string SKAS_B = Request_Forward_msg->getBroker_SK();
    std::string C7     = auth.hash({Session[K].Session_ID ,SKAS_B });                   //(31)
    std::string Na     = auth._xor(C7, Request_Forward_msg-> getC8());                  //(32)
    std::string Device_ID    = auth._xor(Request_Forward_msg->getC4(),Session[K].Session_ID); //(33)
    std::string C5     = auth._xor(Request_Forward_msg->getC6(),Session[K].Session_ID); //(35)
    std::string _Hash5 = auth.hash({Device_ID , Session[K].Session_ID , Na});                 //(34)
    std::string C9     = auth.hash({C5 , Session[K].Session_ID});                       //(36)
    std::string C10    = auth._xor(C9,Session[K].R3);                                   //(37)
    std::string Hash6  = auth.hash({C9 , C10 , Session[K].R3});                         //(38)

    Session_Broker S;
        S.index       = Session[K].index;
        S.Device_port = Session[K].Device_port;
        S.Session_ID  = Session[K].Session_ID;
        S.R3          = Session[K].R3;
        S._Hash5      = _Hash5;
        S.Hash5       = Session[K].Hash5;
        S.Hash6       = Hash6;
        S.C9          = C9;
        S.C10         = C10;
        S.Session_key       = C10;
    Session.at(K) = S;

    if(Session[K].Hash5 == Session[K]._Hash5)
        send(auth.create_Broker_Verification(Session[K].C10,Session[K].Hash6), "gate$o", Session[K].Device_port);
}

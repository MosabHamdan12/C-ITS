#ifndef __Broker_H_
#define __Broker_H_

#include <omnetpp.h>
#include "../msg_m.h"
#include "../authentication.h"
using namespace omnetpp;

struct Session_Broker{
    int index;
    int Device_port ;
    std::string Session_ID ;
    std::string R3;
    std::string _Hash5;
    std::string Hash5;

    std::string Hash6;
    std::string C9;
    std::string C10;

    std::string Session_key;
};

class Broker : public cSimpleModule{
    std::vector<Session_Broker> Session;
    enum{start=1};
    cMessage *selfMsg = nullptr;
    authentication auth;
  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);

    void handleCONNECT(cMessage *msg);
    void handleDevice_Verification(cMessage *msg);
    void handleRequest_Forward(cMessage *msg);
    void handleSessionKey_Verification(cMessage *msg);
};

#endif


#include "Auth_Manager.h"

Define_Module(Auth_Manager);

void Auth_Manager::initialize(){
    srand(time(0));
    rand();
    rand();
    selfMsg = new cMessage("sendTimer");
    selfMsg->setKind(start);
    scheduleAt(simTime(), selfMsg);

}

void Auth_Manager::handleMessage(cMessage *msg){
    if (msg->isSelfMessage()) {
            ASSERT(msg == selfMsg);
            switch (selfMsg->getKind()) {
                case start:
                    break;
            }
     }else{
         Base_msg *_msg = check_and_cast<Base_msg *>(msg);
         switch (_msg->getPacket_type()) {
             case _Registration:
                 handleRegistration(msg);
                 break;
             case _Request:
                 handleRequest(msg);
                 break;
         }
     }
}
void Auth_Manager::handleRegistration(cMessage *msg){
    Registration *Registration_msg = check_and_cast<Registration *>(msg);
    std::string SN = auth.hash(rand() % (1000000 - 9999999));
    Session_Manager S;
       S.index = Session.size();
       S.Device_port = Registration_msg->getPort();
       S.MK1  = auth.hash(rand() % (1000000 - 9999999));
       S.MK2  = auth.hash(rand() % (1000000 - 9999999));
       S.SN   = SN;
       S.Na   = auth.hash(rand() % (1000000 - 9999999));
       S.Device_AID = auth.hash(auth._xor(Registration_msg->getDevice_ID(), SN)); //(1)
    Session.push_back(S);
    int K = Session.size()-1;
    std::string Device_MID   = auth._xor(Session[K].Device_AID, Session[K].MK1); //(2)
    std::string Device_SK    = auth._xor(Device_MID, Session[K].MK2);            //(3)
    std::string Hash1        = auth.hash(Device_MID);                            //(4)

    send(auth.create_parameters(Session[K].Device_AID,Device_SK,Hash1), "gate$o", Session[K].Device_port);
}
void Auth_Manager::handleRequest(cMessage *msg){
    Request *Request_msg = check_and_cast<Request *>(msg);
       int K =-1;
    for (auto i = Session.begin(); i != Session.end(); ++i)
        if (i->Device_port == msg->getArrivalGate()->getIndex())
            K = i->index;

    std::string Device_MID = auth._xor(Session[K].Device_AID,Session[K].MK1);                               //(9)
    std::string Device_SK  = auth._xor(Device_MID,Session[K].MK2);                                          //(10)
    std::string R1         = auth._xor(Request_msg->getC1(),Device_SK);                                     //(11)
    std::string Device_ID  = auth._xor(auth.hash(Device_MID),Request_msg->getC2() );                        //(12)
    std::string Broker_ID  = auth._xor(Request_msg->getC3(),Device_ID );                                    //(13)
    std::string Hash2      = auth.hash({Session[K].Device_AID,R1,Request_msg->getC1(),Device_ID,Broker_ID});//(14)

    if(Hash2==Request_msg->getHash2()){
        std::string R2       = auth.hash({ R1 , auth.hash(Device_MID) }); //(15)
        std::string Verifier = auth._xor(R2,Session[K].Na) ;              //(16)
        std::string Hash3    = auth.hash({ R2 , Verifier });              //(17)

        send(auth.create_Manager_Verification(Verifier,Hash3), "gate$o", Session[K].Device_port);

        std::string Broker_AID   = auth.hash({Broker_ID ,Session[K].SN});               //(21)
        std::string Broker_MID   = auth._xor(Broker_AID,Session[K].MK1);                //(22)
        std::string Broker_SK    = auth._xor(Broker_MID,Session[K].MK2);                //(23)
        std::string C4           = auth._xor(Device_ID,Broker_ID);                      //(24)
        std::string C5           = auth.hash({Device_SK , R2  }) ;                      //(25)
        std::string C6           = auth._xor(C5,Broker_ID);                             //(26)
        std::string C7           = auth.hash({Broker_ID , Broker_SK}) ;                 //(27)
        std::string C8           = auth._xor(C7,Session[K].Na);                         //(28)
        std::string Hash4        = auth.hash({ C4 , C6 , C8 , Broker_ID , Broker_SK }) ;//(29)

       send(auth.create_Request_Forward(Broker_SK,C4,C6,C8,Hash4,Session[K].Device_port), "gate$o", 6);
    }
}

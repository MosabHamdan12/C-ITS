#ifndef __Auth_Manager_H_
#define __Auth_Manager_H_

#include <omnetpp.h>
#include "../authentication.h"
#include "../msg_m.h"
using namespace omnetpp;

struct Session_Manager{
    int index;
    int Device_port ;
    std::string MK1;
    std::string MK2;
    std::string SN;
    std::string Na;
    std::string Device_AID;
};

class Auth_Manager : public cSimpleModule{
    enum{start=1};
    cMessage *selfMsg = nullptr;
    authentication auth;
    std::vector<Session_Manager> Session;
  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    void handleRegistration(cMessage *msg);
    void handleRequest(cMessage *msg);
};

#endif

//
// Generated file, do not edit! Created by nedtool 5.6 from msg.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include "msg_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i=0; i<n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i=0; i<n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i=0; i<n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp


// forward
template<typename T, typename A>
std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec);

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// operator<< for std::vector<T>
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

EXECUTE_ON_STARTUP(
    omnetpp::cEnum *e = omnetpp::cEnum::find("_Packet_type");
    if (!e) omnetpp::enums.getInstance()->add(e = new omnetpp::cEnum("_Packet_type"));
    e->insert(_CONNECT, "_CONNECT");
    e->insert(_Registration, "_Registration");
    e->insert(_parameters, "_parameters");
    e->insert(_Request, "_Request");
    e->insert(_Manager_Verification, "_Manager_Verification");
    e->insert(_Device_Verification, "_Device_Verification");
    e->insert(_Request_Forward, "_Request_Forward");
    e->insert(_Broker_Verification, "_Broker_Verification");
    e->insert(_SessionKey_Verification, "_SessionKey_Verification");
)

Register_Class(Base_msg)

Base_msg::Base_msg(const char *name, short kind) : ::omnetpp::cMessage(name,kind)
{
    this->Packet_type = 0;
}

Base_msg::Base_msg(const Base_msg& other) : ::omnetpp::cMessage(other)
{
    copy(other);
}

Base_msg::~Base_msg()
{
}

Base_msg& Base_msg::operator=(const Base_msg& other)
{
    if (this==&other) return *this;
    ::omnetpp::cMessage::operator=(other);
    copy(other);
    return *this;
}

void Base_msg::copy(const Base_msg& other)
{
    this->Packet_type = other.Packet_type;
}

void Base_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::omnetpp::cMessage::parsimPack(b);
    doParsimPacking(b,this->Packet_type);
}

void Base_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::omnetpp::cMessage::parsimUnpack(b);
    doParsimUnpacking(b,this->Packet_type);
}

int Base_msg::getPacket_type() const
{
    return this->Packet_type;
}

void Base_msg::setPacket_type(int Packet_type)
{
    this->Packet_type = Packet_type;
}

class Base_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    Base_msgDescriptor();
    virtual ~Base_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(Base_msgDescriptor)

Base_msgDescriptor::Base_msgDescriptor() : omnetpp::cClassDescriptor("Base_msg", "omnetpp::cMessage")
{
    propertynames = nullptr;
}

Base_msgDescriptor::~Base_msgDescriptor()
{
    delete[] propertynames;
}

bool Base_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Base_msg *>(obj)!=nullptr;
}

const char **Base_msgDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *Base_msgDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int Base_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 1+basedesc->getFieldCount() : 1;
}

unsigned int Base_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
    };
    return (field>=0 && field<1) ? fieldTypeFlags[field] : 0;
}

const char *Base_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Packet_type",
    };
    return (field>=0 && field<1) ? fieldNames[field] : nullptr;
}

int Base_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='P' && strcmp(fieldName, "Packet_type")==0) return base+0;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *Base_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",
    };
    return (field>=0 && field<1) ? fieldTypeStrings[field] : nullptr;
}

const char **Base_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *Base_msgDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int Base_msgDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Base_msg *pp = (Base_msg *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *Base_msgDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Base_msg *pp = (Base_msg *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string Base_msgDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Base_msg *pp = (Base_msg *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getPacket_type());
        default: return "";
    }
}

bool Base_msgDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Base_msg *pp = (Base_msg *)object; (void)pp;
    switch (field) {
        case 0: pp->setPacket_type(string2long(value)); return true;
        default: return false;
    }
}

const char *Base_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *Base_msgDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Base_msg *pp = (Base_msg *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(CONNECT)

CONNECT::CONNECT(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_CONNECT);

}

CONNECT::CONNECT(const CONNECT& other) : ::Base_msg(other)
{
    copy(other);
}

CONNECT::~CONNECT()
{
}

CONNECT& CONNECT::operator=(const CONNECT& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void CONNECT::copy(const CONNECT& other)
{
    this->Device_ID = other.Device_ID;
}

void CONNECT::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->Device_ID);
}

void CONNECT::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->Device_ID);
}

const char * CONNECT::getDevice_ID() const
{
    return this->Device_ID.c_str();
}

void CONNECT::setDevice_ID(const char * Device_ID)
{
    this->Device_ID = Device_ID;
}

class CONNECTDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    CONNECTDescriptor();
    virtual ~CONNECTDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(CONNECTDescriptor)

CONNECTDescriptor::CONNECTDescriptor() : omnetpp::cClassDescriptor("CONNECT", "Base_msg")
{
    propertynames = nullptr;
}

CONNECTDescriptor::~CONNECTDescriptor()
{
    delete[] propertynames;
}

bool CONNECTDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<CONNECT *>(obj)!=nullptr;
}

const char **CONNECTDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *CONNECTDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int CONNECTDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 1+basedesc->getFieldCount() : 1;
}

unsigned int CONNECTDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
    };
    return (field>=0 && field<1) ? fieldTypeFlags[field] : 0;
}

const char *CONNECTDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Device_ID",
    };
    return (field>=0 && field<1) ? fieldNames[field] : nullptr;
}

int CONNECTDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='D' && strcmp(fieldName, "Device_ID")==0) return base+0;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *CONNECTDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
    };
    return (field>=0 && field<1) ? fieldTypeStrings[field] : nullptr;
}

const char **CONNECTDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *CONNECTDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int CONNECTDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    CONNECT *pp = (CONNECT *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *CONNECTDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    CONNECT *pp = (CONNECT *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string CONNECTDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    CONNECT *pp = (CONNECT *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getDevice_ID());
        default: return "";
    }
}

bool CONNECTDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    CONNECT *pp = (CONNECT *)object; (void)pp;
    switch (field) {
        case 0: pp->setDevice_ID((value)); return true;
        default: return false;
    }
}

const char *CONNECTDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *CONNECTDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    CONNECT *pp = (CONNECT *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(Registration)

Registration::Registration(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_Registration);

    this->port = 0;
}

Registration::Registration(const Registration& other) : ::Base_msg(other)
{
    copy(other);
}

Registration::~Registration()
{
}

Registration& Registration::operator=(const Registration& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void Registration::copy(const Registration& other)
{
    this->port = other.port;
    this->Device_ID = other.Device_ID;
}

void Registration::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->port);
    doParsimPacking(b,this->Device_ID);
}

void Registration::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->port);
    doParsimUnpacking(b,this->Device_ID);
}

int Registration::getPort() const
{
    return this->port;
}

void Registration::setPort(int port)
{
    this->port = port;
}

const char * Registration::getDevice_ID() const
{
    return this->Device_ID.c_str();
}

void Registration::setDevice_ID(const char * Device_ID)
{
    this->Device_ID = Device_ID;
}

class RegistrationDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    RegistrationDescriptor();
    virtual ~RegistrationDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(RegistrationDescriptor)

RegistrationDescriptor::RegistrationDescriptor() : omnetpp::cClassDescriptor("Registration", "Base_msg")
{
    propertynames = nullptr;
}

RegistrationDescriptor::~RegistrationDescriptor()
{
    delete[] propertynames;
}

bool RegistrationDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Registration *>(obj)!=nullptr;
}

const char **RegistrationDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *RegistrationDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int RegistrationDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount() : 2;
}

unsigned int RegistrationDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<2) ? fieldTypeFlags[field] : 0;
}

const char *RegistrationDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "port",
        "Device_ID",
    };
    return (field>=0 && field<2) ? fieldNames[field] : nullptr;
}

int RegistrationDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='p' && strcmp(fieldName, "port")==0) return base+0;
    if (fieldName[0]=='D' && strcmp(fieldName, "Device_ID")==0) return base+1;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *RegistrationDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "string",
    };
    return (field>=0 && field<2) ? fieldTypeStrings[field] : nullptr;
}

const char **RegistrationDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *RegistrationDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int RegistrationDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Registration *pp = (Registration *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *RegistrationDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Registration *pp = (Registration *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string RegistrationDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Registration *pp = (Registration *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getPort());
        case 1: return oppstring2string(pp->getDevice_ID());
        default: return "";
    }
}

bool RegistrationDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Registration *pp = (Registration *)object; (void)pp;
    switch (field) {
        case 0: pp->setPort(string2long(value)); return true;
        case 1: pp->setDevice_ID((value)); return true;
        default: return false;
    }
}

const char *RegistrationDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *RegistrationDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Registration *pp = (Registration *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(parameters)

parameters::parameters(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_parameters);

}

parameters::parameters(const parameters& other) : ::Base_msg(other)
{
    copy(other);
}

parameters::~parameters()
{
}

parameters& parameters::operator=(const parameters& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void parameters::copy(const parameters& other)
{
    this->Device_AID = other.Device_AID;
    this->Device_SK = other.Device_SK;
    this->Hash1 = other.Hash1;
}

void parameters::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->Device_AID);
    doParsimPacking(b,this->Device_SK);
    doParsimPacking(b,this->Hash1);
}

void parameters::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->Device_AID);
    doParsimUnpacking(b,this->Device_SK);
    doParsimUnpacking(b,this->Hash1);
}

const char * parameters::getDevice_AID() const
{
    return this->Device_AID.c_str();
}

void parameters::setDevice_AID(const char * Device_AID)
{
    this->Device_AID = Device_AID;
}

const char * parameters::getDevice_SK() const
{
    return this->Device_SK.c_str();
}

void parameters::setDevice_SK(const char * Device_SK)
{
    this->Device_SK = Device_SK;
}

const char * parameters::getHash1() const
{
    return this->Hash1.c_str();
}

void parameters::setHash1(const char * Hash1)
{
    this->Hash1 = Hash1;
}

class parametersDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    parametersDescriptor();
    virtual ~parametersDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(parametersDescriptor)

parametersDescriptor::parametersDescriptor() : omnetpp::cClassDescriptor("parameters", "Base_msg")
{
    propertynames = nullptr;
}

parametersDescriptor::~parametersDescriptor()
{
    delete[] propertynames;
}

bool parametersDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<parameters *>(obj)!=nullptr;
}

const char **parametersDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *parametersDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int parametersDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 3+basedesc->getFieldCount() : 3;
}

unsigned int parametersDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<3) ? fieldTypeFlags[field] : 0;
}

const char *parametersDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Device_AID",
        "Device_SK",
        "Hash1",
    };
    return (field>=0 && field<3) ? fieldNames[field] : nullptr;
}

int parametersDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='D' && strcmp(fieldName, "Device_AID")==0) return base+0;
    if (fieldName[0]=='D' && strcmp(fieldName, "Device_SK")==0) return base+1;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash1")==0) return base+2;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *parametersDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "string",
        "string",
    };
    return (field>=0 && field<3) ? fieldTypeStrings[field] : nullptr;
}

const char **parametersDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *parametersDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int parametersDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    parameters *pp = (parameters *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *parametersDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    parameters *pp = (parameters *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string parametersDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    parameters *pp = (parameters *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getDevice_AID());
        case 1: return oppstring2string(pp->getDevice_SK());
        case 2: return oppstring2string(pp->getHash1());
        default: return "";
    }
}

bool parametersDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    parameters *pp = (parameters *)object; (void)pp;
    switch (field) {
        case 0: pp->setDevice_AID((value)); return true;
        case 1: pp->setDevice_SK((value)); return true;
        case 2: pp->setHash1((value)); return true;
        default: return false;
    }
}

const char *parametersDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *parametersDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    parameters *pp = (parameters *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(Request)

Request::Request(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_Request);

}

Request::Request(const Request& other) : ::Base_msg(other)
{
    copy(other);
}

Request::~Request()
{
}

Request& Request::operator=(const Request& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void Request::copy(const Request& other)
{
    this->C1 = other.C1;
    this->C2 = other.C2;
    this->C3 = other.C3;
    this->Hash2 = other.Hash2;
}

void Request::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->C1);
    doParsimPacking(b,this->C2);
    doParsimPacking(b,this->C3);
    doParsimPacking(b,this->Hash2);
}

void Request::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->C1);
    doParsimUnpacking(b,this->C2);
    doParsimUnpacking(b,this->C3);
    doParsimUnpacking(b,this->Hash2);
}

const char * Request::getC1() const
{
    return this->C1.c_str();
}

void Request::setC1(const char * C1)
{
    this->C1 = C1;
}

const char * Request::getC2() const
{
    return this->C2.c_str();
}

void Request::setC2(const char * C2)
{
    this->C2 = C2;
}

const char * Request::getC3() const
{
    return this->C3.c_str();
}

void Request::setC3(const char * C3)
{
    this->C3 = C3;
}

const char * Request::getHash2() const
{
    return this->Hash2.c_str();
}

void Request::setHash2(const char * Hash2)
{
    this->Hash2 = Hash2;
}

class RequestDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    RequestDescriptor();
    virtual ~RequestDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(RequestDescriptor)

RequestDescriptor::RequestDescriptor() : omnetpp::cClassDescriptor("Request", "Base_msg")
{
    propertynames = nullptr;
}

RequestDescriptor::~RequestDescriptor()
{
    delete[] propertynames;
}

bool RequestDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Request *>(obj)!=nullptr;
}

const char **RequestDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *RequestDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int RequestDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 4+basedesc->getFieldCount() : 4;
}

unsigned int RequestDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<4) ? fieldTypeFlags[field] : 0;
}

const char *RequestDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "C1",
        "C2",
        "C3",
        "Hash2",
    };
    return (field>=0 && field<4) ? fieldNames[field] : nullptr;
}

int RequestDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='C' && strcmp(fieldName, "C1")==0) return base+0;
    if (fieldName[0]=='C' && strcmp(fieldName, "C2")==0) return base+1;
    if (fieldName[0]=='C' && strcmp(fieldName, "C3")==0) return base+2;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash2")==0) return base+3;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *RequestDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "string",
        "string",
        "string",
    };
    return (field>=0 && field<4) ? fieldTypeStrings[field] : nullptr;
}

const char **RequestDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *RequestDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int RequestDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Request *pp = (Request *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *RequestDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Request *pp = (Request *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string RequestDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Request *pp = (Request *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getC1());
        case 1: return oppstring2string(pp->getC2());
        case 2: return oppstring2string(pp->getC3());
        case 3: return oppstring2string(pp->getHash2());
        default: return "";
    }
}

bool RequestDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Request *pp = (Request *)object; (void)pp;
    switch (field) {
        case 0: pp->setC1((value)); return true;
        case 1: pp->setC2((value)); return true;
        case 2: pp->setC3((value)); return true;
        case 3: pp->setHash2((value)); return true;
        default: return false;
    }
}

const char *RequestDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *RequestDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Request *pp = (Request *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(Manager_Verification)

Manager_Verification::Manager_Verification(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_Manager_Verification);

}

Manager_Verification::Manager_Verification(const Manager_Verification& other) : ::Base_msg(other)
{
    copy(other);
}

Manager_Verification::~Manager_Verification()
{
}

Manager_Verification& Manager_Verification::operator=(const Manager_Verification& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void Manager_Verification::copy(const Manager_Verification& other)
{
    this->Verifier = other.Verifier;
    this->Hash3 = other.Hash3;
}

void Manager_Verification::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->Verifier);
    doParsimPacking(b,this->Hash3);
}

void Manager_Verification::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->Verifier);
    doParsimUnpacking(b,this->Hash3);
}

const char * Manager_Verification::getVerifier() const
{
    return this->Verifier.c_str();
}

void Manager_Verification::setVerifier(const char * Verifier)
{
    this->Verifier = Verifier;
}

const char * Manager_Verification::getHash3() const
{
    return this->Hash3.c_str();
}

void Manager_Verification::setHash3(const char * Hash3)
{
    this->Hash3 = Hash3;
}

class Manager_VerificationDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    Manager_VerificationDescriptor();
    virtual ~Manager_VerificationDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(Manager_VerificationDescriptor)

Manager_VerificationDescriptor::Manager_VerificationDescriptor() : omnetpp::cClassDescriptor("Manager_Verification", "Base_msg")
{
    propertynames = nullptr;
}

Manager_VerificationDescriptor::~Manager_VerificationDescriptor()
{
    delete[] propertynames;
}

bool Manager_VerificationDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Manager_Verification *>(obj)!=nullptr;
}

const char **Manager_VerificationDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *Manager_VerificationDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int Manager_VerificationDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount() : 2;
}

unsigned int Manager_VerificationDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<2) ? fieldTypeFlags[field] : 0;
}

const char *Manager_VerificationDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Verifier",
        "Hash3",
    };
    return (field>=0 && field<2) ? fieldNames[field] : nullptr;
}

int Manager_VerificationDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='V' && strcmp(fieldName, "Verifier")==0) return base+0;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash3")==0) return base+1;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *Manager_VerificationDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "string",
    };
    return (field>=0 && field<2) ? fieldTypeStrings[field] : nullptr;
}

const char **Manager_VerificationDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *Manager_VerificationDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int Manager_VerificationDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Manager_Verification *pp = (Manager_Verification *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *Manager_VerificationDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Manager_Verification *pp = (Manager_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string Manager_VerificationDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Manager_Verification *pp = (Manager_Verification *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getVerifier());
        case 1: return oppstring2string(pp->getHash3());
        default: return "";
    }
}

bool Manager_VerificationDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Manager_Verification *pp = (Manager_Verification *)object; (void)pp;
    switch (field) {
        case 0: pp->setVerifier((value)); return true;
        case 1: pp->setHash3((value)); return true;
        default: return false;
    }
}

const char *Manager_VerificationDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *Manager_VerificationDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Manager_Verification *pp = (Manager_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(Device_Verification)

Device_Verification::Device_Verification(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_Device_Verification);

}

Device_Verification::Device_Verification(const Device_Verification& other) : ::Base_msg(other)
{
    copy(other);
}

Device_Verification::~Device_Verification()
{
}

Device_Verification& Device_Verification::operator=(const Device_Verification& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void Device_Verification::copy(const Device_Verification& other)
{
    this->Hash5 = other.Hash5;
}

void Device_Verification::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->Hash5);
}

void Device_Verification::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->Hash5);
}

const char * Device_Verification::getHash5() const
{
    return this->Hash5.c_str();
}

void Device_Verification::setHash5(const char * Hash5)
{
    this->Hash5 = Hash5;
}

class Device_VerificationDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    Device_VerificationDescriptor();
    virtual ~Device_VerificationDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(Device_VerificationDescriptor)

Device_VerificationDescriptor::Device_VerificationDescriptor() : omnetpp::cClassDescriptor("Device_Verification", "Base_msg")
{
    propertynames = nullptr;
}

Device_VerificationDescriptor::~Device_VerificationDescriptor()
{
    delete[] propertynames;
}

bool Device_VerificationDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Device_Verification *>(obj)!=nullptr;
}

const char **Device_VerificationDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *Device_VerificationDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int Device_VerificationDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 1+basedesc->getFieldCount() : 1;
}

unsigned int Device_VerificationDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
    };
    return (field>=0 && field<1) ? fieldTypeFlags[field] : 0;
}

const char *Device_VerificationDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Hash5",
    };
    return (field>=0 && field<1) ? fieldNames[field] : nullptr;
}

int Device_VerificationDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash5")==0) return base+0;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *Device_VerificationDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
    };
    return (field>=0 && field<1) ? fieldTypeStrings[field] : nullptr;
}

const char **Device_VerificationDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *Device_VerificationDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int Device_VerificationDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Device_Verification *pp = (Device_Verification *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *Device_VerificationDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Device_Verification *pp = (Device_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string Device_VerificationDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Device_Verification *pp = (Device_Verification *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getHash5());
        default: return "";
    }
}

bool Device_VerificationDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Device_Verification *pp = (Device_Verification *)object; (void)pp;
    switch (field) {
        case 0: pp->setHash5((value)); return true;
        default: return false;
    }
}

const char *Device_VerificationDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *Device_VerificationDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Device_Verification *pp = (Device_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(Request_Forward)

Request_Forward::Request_Forward(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_Request_Forward);

    this->port = 0;
}

Request_Forward::Request_Forward(const Request_Forward& other) : ::Base_msg(other)
{
    copy(other);
}

Request_Forward::~Request_Forward()
{
}

Request_Forward& Request_Forward::operator=(const Request_Forward& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void Request_Forward::copy(const Request_Forward& other)
{
    this->port = other.port;
    this->Broker_SK = other.Broker_SK;
    this->C4 = other.C4;
    this->C6 = other.C6;
    this->C8 = other.C8;
    this->Hash4 = other.Hash4;
}

void Request_Forward::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->port);
    doParsimPacking(b,this->Broker_SK);
    doParsimPacking(b,this->C4);
    doParsimPacking(b,this->C6);
    doParsimPacking(b,this->C8);
    doParsimPacking(b,this->Hash4);
}

void Request_Forward::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->port);
    doParsimUnpacking(b,this->Broker_SK);
    doParsimUnpacking(b,this->C4);
    doParsimUnpacking(b,this->C6);
    doParsimUnpacking(b,this->C8);
    doParsimUnpacking(b,this->Hash4);
}

int Request_Forward::getPort() const
{
    return this->port;
}

void Request_Forward::setPort(int port)
{
    this->port = port;
}

const char * Request_Forward::getBroker_SK() const
{
    return this->Broker_SK.c_str();
}

void Request_Forward::setBroker_SK(const char * Broker_SK)
{
    this->Broker_SK = Broker_SK;
}

const char * Request_Forward::getC4() const
{
    return this->C4.c_str();
}

void Request_Forward::setC4(const char * C4)
{
    this->C4 = C4;
}

const char * Request_Forward::getC6() const
{
    return this->C6.c_str();
}

void Request_Forward::setC6(const char * C6)
{
    this->C6 = C6;
}

const char * Request_Forward::getC8() const
{
    return this->C8.c_str();
}

void Request_Forward::setC8(const char * C8)
{
    this->C8 = C8;
}

const char * Request_Forward::getHash4() const
{
    return this->Hash4.c_str();
}

void Request_Forward::setHash4(const char * Hash4)
{
    this->Hash4 = Hash4;
}

class Request_ForwardDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    Request_ForwardDescriptor();
    virtual ~Request_ForwardDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(Request_ForwardDescriptor)

Request_ForwardDescriptor::Request_ForwardDescriptor() : omnetpp::cClassDescriptor("Request_Forward", "Base_msg")
{
    propertynames = nullptr;
}

Request_ForwardDescriptor::~Request_ForwardDescriptor()
{
    delete[] propertynames;
}

bool Request_ForwardDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Request_Forward *>(obj)!=nullptr;
}

const char **Request_ForwardDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *Request_ForwardDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int Request_ForwardDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 6+basedesc->getFieldCount() : 6;
}

unsigned int Request_ForwardDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<6) ? fieldTypeFlags[field] : 0;
}

const char *Request_ForwardDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "port",
        "Broker_SK",
        "C4",
        "C6",
        "C8",
        "Hash4",
    };
    return (field>=0 && field<6) ? fieldNames[field] : nullptr;
}

int Request_ForwardDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='p' && strcmp(fieldName, "port")==0) return base+0;
    if (fieldName[0]=='B' && strcmp(fieldName, "Broker_SK")==0) return base+1;
    if (fieldName[0]=='C' && strcmp(fieldName, "C4")==0) return base+2;
    if (fieldName[0]=='C' && strcmp(fieldName, "C6")==0) return base+3;
    if (fieldName[0]=='C' && strcmp(fieldName, "C8")==0) return base+4;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash4")==0) return base+5;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *Request_ForwardDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "string",
        "string",
        "string",
        "string",
        "string",
    };
    return (field>=0 && field<6) ? fieldTypeStrings[field] : nullptr;
}

const char **Request_ForwardDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *Request_ForwardDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int Request_ForwardDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Request_Forward *pp = (Request_Forward *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *Request_ForwardDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Request_Forward *pp = (Request_Forward *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string Request_ForwardDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Request_Forward *pp = (Request_Forward *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getPort());
        case 1: return oppstring2string(pp->getBroker_SK());
        case 2: return oppstring2string(pp->getC4());
        case 3: return oppstring2string(pp->getC6());
        case 4: return oppstring2string(pp->getC8());
        case 5: return oppstring2string(pp->getHash4());
        default: return "";
    }
}

bool Request_ForwardDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Request_Forward *pp = (Request_Forward *)object; (void)pp;
    switch (field) {
        case 0: pp->setPort(string2long(value)); return true;
        case 1: pp->setBroker_SK((value)); return true;
        case 2: pp->setC4((value)); return true;
        case 3: pp->setC6((value)); return true;
        case 4: pp->setC8((value)); return true;
        case 5: pp->setHash4((value)); return true;
        default: return false;
    }
}

const char *Request_ForwardDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *Request_ForwardDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Request_Forward *pp = (Request_Forward *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(Broker_Verification)

Broker_Verification::Broker_Verification(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_Broker_Verification);

}

Broker_Verification::Broker_Verification(const Broker_Verification& other) : ::Base_msg(other)
{
    copy(other);
}

Broker_Verification::~Broker_Verification()
{
}

Broker_Verification& Broker_Verification::operator=(const Broker_Verification& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void Broker_Verification::copy(const Broker_Verification& other)
{
    this->C10 = other.C10;
    this->Hash6 = other.Hash6;
}

void Broker_Verification::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->C10);
    doParsimPacking(b,this->Hash6);
}

void Broker_Verification::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->C10);
    doParsimUnpacking(b,this->Hash6);
}

const char * Broker_Verification::getC10() const
{
    return this->C10.c_str();
}

void Broker_Verification::setC10(const char * C10)
{
    this->C10 = C10;
}

const char * Broker_Verification::getHash6() const
{
    return this->Hash6.c_str();
}

void Broker_Verification::setHash6(const char * Hash6)
{
    this->Hash6 = Hash6;
}

class Broker_VerificationDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    Broker_VerificationDescriptor();
    virtual ~Broker_VerificationDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(Broker_VerificationDescriptor)

Broker_VerificationDescriptor::Broker_VerificationDescriptor() : omnetpp::cClassDescriptor("Broker_Verification", "Base_msg")
{
    propertynames = nullptr;
}

Broker_VerificationDescriptor::~Broker_VerificationDescriptor()
{
    delete[] propertynames;
}

bool Broker_VerificationDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<Broker_Verification *>(obj)!=nullptr;
}

const char **Broker_VerificationDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *Broker_VerificationDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int Broker_VerificationDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount() : 2;
}

unsigned int Broker_VerificationDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<2) ? fieldTypeFlags[field] : 0;
}

const char *Broker_VerificationDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "C10",
        "Hash6",
    };
    return (field>=0 && field<2) ? fieldNames[field] : nullptr;
}

int Broker_VerificationDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='C' && strcmp(fieldName, "C10")==0) return base+0;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash6")==0) return base+1;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *Broker_VerificationDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "string",
    };
    return (field>=0 && field<2) ? fieldTypeStrings[field] : nullptr;
}

const char **Broker_VerificationDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *Broker_VerificationDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int Broker_VerificationDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    Broker_Verification *pp = (Broker_Verification *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *Broker_VerificationDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Broker_Verification *pp = (Broker_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string Broker_VerificationDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    Broker_Verification *pp = (Broker_Verification *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getC10());
        case 1: return oppstring2string(pp->getHash6());
        default: return "";
    }
}

bool Broker_VerificationDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    Broker_Verification *pp = (Broker_Verification *)object; (void)pp;
    switch (field) {
        case 0: pp->setC10((value)); return true;
        case 1: pp->setHash6((value)); return true;
        default: return false;
    }
}

const char *Broker_VerificationDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *Broker_VerificationDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    Broker_Verification *pp = (Broker_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

Register_Class(SessionKey_Verification)

SessionKey_Verification::SessionKey_Verification(const char *name, short kind) : ::Base_msg(name,kind)
{
    this->setPacket_type(_SessionKey_Verification);

}

SessionKey_Verification::SessionKey_Verification(const SessionKey_Verification& other) : ::Base_msg(other)
{
    copy(other);
}

SessionKey_Verification::~SessionKey_Verification()
{
}

SessionKey_Verification& SessionKey_Verification::operator=(const SessionKey_Verification& other)
{
    if (this==&other) return *this;
    ::Base_msg::operator=(other);
    copy(other);
    return *this;
}

void SessionKey_Verification::copy(const SessionKey_Verification& other)
{
    this->C11 = other.C11;
    this->Hash7 = other.Hash7;
}

void SessionKey_Verification::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::Base_msg::parsimPack(b);
    doParsimPacking(b,this->C11);
    doParsimPacking(b,this->Hash7);
}

void SessionKey_Verification::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::Base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->C11);
    doParsimUnpacking(b,this->Hash7);
}

const char * SessionKey_Verification::getC11() const
{
    return this->C11.c_str();
}

void SessionKey_Verification::setC11(const char * C11)
{
    this->C11 = C11;
}

const char * SessionKey_Verification::getHash7() const
{
    return this->Hash7.c_str();
}

void SessionKey_Verification::setHash7(const char * Hash7)
{
    this->Hash7 = Hash7;
}

class SessionKey_VerificationDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
  public:
    SessionKey_VerificationDescriptor();
    virtual ~SessionKey_VerificationDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(SessionKey_VerificationDescriptor)

SessionKey_VerificationDescriptor::SessionKey_VerificationDescriptor() : omnetpp::cClassDescriptor("SessionKey_Verification", "Base_msg")
{
    propertynames = nullptr;
}

SessionKey_VerificationDescriptor::~SessionKey_VerificationDescriptor()
{
    delete[] propertynames;
}

bool SessionKey_VerificationDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<SessionKey_Verification *>(obj)!=nullptr;
}

const char **SessionKey_VerificationDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *SessionKey_VerificationDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int SessionKey_VerificationDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount() : 2;
}

unsigned int SessionKey_VerificationDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<2) ? fieldTypeFlags[field] : 0;
}

const char *SessionKey_VerificationDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "C11",
        "Hash7",
    };
    return (field>=0 && field<2) ? fieldNames[field] : nullptr;
}

int SessionKey_VerificationDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0]=='C' && strcmp(fieldName, "C11")==0) return base+0;
    if (fieldName[0]=='H' && strcmp(fieldName, "Hash7")==0) return base+1;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *SessionKey_VerificationDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "string",
    };
    return (field>=0 && field<2) ? fieldTypeStrings[field] : nullptr;
}

const char **SessionKey_VerificationDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *SessionKey_VerificationDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int SessionKey_VerificationDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    SessionKey_Verification *pp = (SessionKey_Verification *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

const char *SessionKey_VerificationDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    SessionKey_Verification *pp = (SessionKey_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string SessionKey_VerificationDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    SessionKey_Verification *pp = (SessionKey_Verification *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getC11());
        case 1: return oppstring2string(pp->getHash7());
        default: return "";
    }
}

bool SessionKey_VerificationDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    SessionKey_Verification *pp = (SessionKey_Verification *)object; (void)pp;
    switch (field) {
        case 0: pp->setC11((value)); return true;
        case 1: pp->setHash7((value)); return true;
        default: return false;
    }
}

const char *SessionKey_VerificationDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *SessionKey_VerificationDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    SessionKey_Verification *pp = (SessionKey_Verification *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}



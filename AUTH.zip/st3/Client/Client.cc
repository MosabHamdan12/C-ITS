#include "Client.h"

Define_Module(Client);

void Client::initialize(){

    srand(time(0));
    rand();
    Device_ID = (rand() % (1000000 - 9999999));
    R1 = auth.hash(rand() % (1000000 - 9999999));
    R4 = auth.hash(rand() % (1000000 - 9999999));
    selfMsg = new cMessage("sendTimer");
    selfMsg->setKind(start);
    scheduleAt(simTime(), selfMsg);
}

void Client::handleMessage(cMessage *msg){
    if (msg->isSelfMessage()) {
            ASSERT(msg == selfMsg);
            switch (selfMsg->getKind()) {
                case start:
                    send(auth.create_CONNECT(auth.hash(Device_ID)), "gate$o", 0);
                    break;
            }
     }else{
         Base_msg *_msg = check_and_cast<Base_msg *>(msg);
         switch (_msg->getPacket_type()) {
             case _CONNECT:
                handleCONNECT(msg);
             break;
             case _parameters:
                 handleParameters(msg);
                 break;
             case _Manager_Verification:
                 handleManager_Verification(msg);
                 break;
             case _Broker_Verification:
                 handleBroker_Verification(msg);
                 break;
         }
     }
}
void Client::handleCONNECT(cMessage *msg){
    CONNECT *CONNECT_msg = check_and_cast<CONNECT *>(msg);
    Broker_ID = CONNECT_msg->getDevice_ID();
}
void Client::handleParameters(cMessage *msg){
    parameters *My_msg = check_and_cast<parameters *>(msg);
    std::string Device_AID   = My_msg->getDevice_AID();                                     //(1)
    Device_SK         = My_msg->getDevice_SK();                                             //(3)
    Hash1             = My_msg->getHash1();                                                 //(4)
    std::string C1    = auth._xor(Device_SK, R1);                                           //(5)
    std::string C2    = auth._xor(Hash1, auth.hash(Device_ID) );                            //(6)
    std::string C3    = auth._xor(auth.hash(Device_ID), Broker_ID );                        //(7)
    std::string Hash2 = auth.hash({ Device_AID, R1, C1 ,auth.hash(Device_ID),Broker_ID });  //(8)
    send(auth.create_Request(C1,C2,C3,Hash2), "gate$o", 1);
}
void Client::handleBroker_Verification(cMessage *msg){
    Broker_Verification *My_msg= check_and_cast<Broker_Verification *>(msg);

    std::string C9    = auth.hash({auth.hash({Device_SK,auth.hash({R1,Hash1})}),Broker_ID  }); //(39)
    std::string R3    = auth._xor(C9, My_msg->getC10());                                       //(40)
    std::string Hash6 = auth.hash({C9,My_msg->getC10(),R3});                                   //(41)

    if(My_msg->getHash6()==Hash6){
        Session_key       = auth.hash({ R3,R4});                           //(42)
        std::string C11   = auth._xor(C9, R4);                             //(43)
        std::string Hash7 = auth.hash({Session_key,C11  });                //(44)
        send(auth.create_SessionKey_Verification(C11,Hash7), "gate$o", 0);
        EV << "Session_key : " << Session_key << "\n";
    }
}

void Client::handleManager_Verification(cMessage *msg){
    Manager_Verification *My_msg = check_and_cast<Manager_Verification *>(msg);
    std::string R2    = auth.hash({ R1 , Hash1 });                  //(18)
    std::string Hash3 = auth.hash({R2 , My_msg->getVerifier()  });  //(19)
    std::string Na    = auth._xor(My_msg->getVerifier(), R2);       //(20)

    if(Hash3== My_msg->getHash3()){
        std::string Hash5 = auth.hash({auth.hash(Device_ID),Broker_ID,Na}); //(30)
        send(auth.create_Device_Verification(Hash5), "gate$o", 0);
    }
}

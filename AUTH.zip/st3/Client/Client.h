#ifndef __Client_H_
#define __Client_H_

#include <omnetpp.h>
#include "../msg_m.h"
#include "../authentication.h"

using namespace omnetpp;
class Client : public cSimpleModule{

    int Device_ID ;
    enum{start=1};
    cMessage *selfMsg = nullptr;
    authentication auth;
    std::string Broker_ID;
    std::string Device_SK;
    std::string R1;
    std::string R4;
    std::string Hash1 ;

    std::string Session_key;
  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    void handleCONNECT(cMessage *msg);
    void handleParameters(cMessage *msg);
    void handleManager_Verification(cMessage *msg);
    void handleBroker_Verification(cMessage *msg);
};

#endif
